# భారత వేదం — Android v1.0.0 Firebase Ready v4

Modern Telugu spiritual content app for the Bharatha Vedam Blogger platform.

## Included
- Home dashboard
- Panchang screen with configurable API endpoint
- Festival structure
- Search and Blogger content access
- Social links
- Report/Recheck flow
- Shareable festival card
- Light/dark theme
- Local analytics fallback
- Firebase Analytics bridge
- Firebase Remote Config bridge
- Firebase Cloud Messaging topic subscription + notification receiver
- Firebase Crashlytics bridge
- Optional Firebase Gradle activation when `app/google-services.json` is present
- GitHub Actions build workflow

## Important
No Firebase credentials are included. The app remains buildable without `google-services.json`; Firebase services become active after the file is added and the project is rebuilt.

Final production APK signing still requires a release keystore and Android build environment.
