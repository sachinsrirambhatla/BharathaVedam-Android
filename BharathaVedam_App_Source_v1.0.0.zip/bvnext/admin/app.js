// భారత వేదం Admin Panel — Firebase Web SDK integration point.
// Replace the placeholder firebaseConfig below with the Web App config from your Firebase project.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js';
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js';
import { getFirestore, doc, getDoc, setDoc, collection, addDoc, query, orderBy, getDocs, updateDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js';

const firebaseConfig = window.BHARATHA_VEDAM_FIREBASE_CONFIG || {
  apiKey: 'REPLACE_ME', authDomain: 'REPLACE_ME', projectId: 'REPLACE_ME', storageBucket: 'REPLACE_ME', messagingSenderId: 'REPLACE_ME', appId: 'REPLACE_ME'
};
const configured = firebaseConfig.apiKey !== 'REPLACE_ME';
const msg = (t) => document.getElementById('loginMsg').textContent = t;
let auth, db;
if(configured){ const app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app); onAuthStateChanged(auth, async user=>{ if(user){document.getElementById('login').hidden=true;document.getElementById('dashboard').hidden=false;document.getElementById('logout').hidden=false;await loadAll();}else{document.getElementById('login').hidden=false;document.getElementById('dashboard').hidden=true;document.getElementById('logout').hidden=true;} }); }
else msg('Firebase Web configuration ఇంకా జోడించలేదు.');

document.getElementById('loginBtn').onclick=async()=>{if(!configured)return msg('ముందుగా Firebase Web config జోడించాలి.');try{await signInWithEmailAndPassword(auth,email.value,password.value);msg('');}catch(e){msg('Login విఫలమైంది: '+e.message)}};
document.getElementById('logout').onclick=()=>signOut(auth);
document.querySelector('[data-save="thought"]').onclick=async()=>{await setDoc(doc(db,'app_config','global'),{todayThought:thought.value},{merge:true});alert('Today’s Thought saved.');};
document.querySelector('[data-save="config"]').onclick=async()=>{await setDoc(doc(db,'app_config','global'),{adsEnabled:adsEnabled.checked,affiliateEnabled:affiliateEnabled.checked,maintenanceMode:maintenanceMode.checked,minSupportedVersion:minVersion.value,panchangEndpoint:panchangEndpoint.value},{merge:true});alert('Configuration saved.');};
document.getElementById('addFestival').onclick=async()=>{await addDoc(collection(db,'festivals'),{name:festivalName.value,date:festivalDate.value,tithi:festivalTithi.value,pujaTiming:festivalTiming.value,significance:festivalSignificance.value,articleUrl:festivalUrl.value,published:true,createdAt:serverTimestamp()});alert('Festival added.');};
document.getElementById('sendNotif').onclick=async()=>{alert('Notification sending requires the deployed sendTopicNotification Cloud Function.');};
document.getElementById('refreshReports').onclick=loadReports;
async function loadAll(){await loadConfig();await loadReports();await loadAnalytics();}
async function loadConfig(){const s=await getDoc(doc(db,'app_config','global'));if(!s.exists())return;const d=s.data();thought.value=d.todayThought||'';adsEnabled.checked=!!d.adsEnabled;affiliateEnabled.checked=!!d.affiliateEnabled;maintenanceMode.checked=!!d.maintenanceMode;minVersion.value=d.minSupportedVersion||'';panchangEndpoint.value=d.panchangEndpoint||'';}
async function loadReports(){const el=document.getElementById('reports');el.textContent='Loading...';const q=query(collection(db,'reports'),orderBy('createdAt','desc'));const ss=await getDocs(q);el.innerHTML='';ss.forEach(s=>{const d=s.data();const div=document.createElement('div');div.className='report';div.innerHTML=`<b>${esc(d.postTitle||'Untitled')}</b><div class="muted">${esc(d.type||'Other')} · <span class="status">${esc(d.status||'Pending')}</span></div><p>${esc(d.feedback||'')}</p><button>Mark Reviewed</button>`;div.querySelector('button').onclick=async()=>{await updateDoc(s.ref,{status:'Reviewed',lastReviewed:serverTimestamp()});loadReports()};el.appendChild(div)});}
async function loadAnalytics(){const ss=await getDocs(collection(db,'analytics_daily'));let opens=0,views=0,unique=0;ss.forEach(s=>{const d=s.data();opens+=Number(d.appOpens||0);views+=Number(d.postViews||0);unique+=Number(d.uniqueVisitors||0)});document.getElementById('analytics').innerHTML=`<b>Total recorded app opens:</b> ${opens}<br><b>Total recorded post views:</b> ${views}<br><b>Recorded unique visitors:</b> ${unique}<p class="muted">Productionలో unique visitors కోసం server-side identity/analytics logic అవసరం.</p>`;}
function esc(x){return String(x).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
