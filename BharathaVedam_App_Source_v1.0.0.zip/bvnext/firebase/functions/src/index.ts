import {onCall, HttpsError} from "firebase-functions/v2/https";
import {onDocumentCreated} from "firebase-functions/v2/firestore";
import {initializeApp} from "firebase-admin/app";
import {getFirestore, FieldValue} from "firebase-admin/firestore";
import {getMessaging} from "firebase-admin/messaging";

initializeApp();
const db = getFirestore();

export const recordPostView = onCall(async (request) => {
  const data = request.data || {};
  const postUrl = String(data.postUrl || "").trim();
  const postTitle = String(data.postTitle || "").trim();
  if (!postUrl) throw new HttpsError("invalid-argument", "postUrl is required");
  const id = Buffer.from(postUrl).toString("base64url").slice(0, 100);
  await db.collection("post_views").doc(id).set({postUrl, postTitle, views: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp()}, {merge:true});
  return {ok:true};
});

export const recordDailyOpen = onCall(async (request) => {
  const date = String(request.data?.date || "").trim();
  if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(date)) throw new HttpsError("invalid-argument", "date must be YYYY-MM-DD");
  await db.collection("analytics_daily").doc(date).set({appOpens: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp()}, {merge:true});
  return {ok:true};
});

export const sendTopicNotification = onCall(async (request) => {
  if (request.auth?.token.admin !== true) throw new HttpsError("permission-denied", "Admin only");
  const topic = String(request.data?.topic || "").trim();
  const title = String(request.data?.title || "భారత వేదం").trim();
  const body = String(request.data?.body || "").trim();
  if (!topic || !body) throw new HttpsError("invalid-argument", "topic and body are required");
  const id = await getMessaging().send({topic, notification:{title, body}});
  return {messageId:id};
});

export const onReportCreated = onDocumentCreated("reports/{reportId}", async (event) => {
  const snap = event.data;
  if (!snap) return;
  await db.collection("admin_events").add({type:"new_report", reportId:event.params.reportId, createdAt:FieldValue.serverTimestamp(), report:snap.data()});
});
