# భారత వేదం — Firebase backend package

ఈ folder production Firebase integrationకు blueprint.

## Collections
- `app_config/global`
- `thoughts/*`
- `festivals/*`
- `reports/*`
- `post_views/*`
- `analytics_daily/*`
- `users/*`

## Admin security
Firestore writes for configuration/content require a Firebase Auth custom claim: `admin=true`.
Do not put service-account credentials inside the Android app.

## Functions
- `recordPostView` — secure server-side post-view increment
- `recordDailyOpen` — daily app-open aggregation
- `sendTopicNotification` — admin-only FCM topic notification
- `onReportCreated` — creates an admin event when a report arrives

## Production notes
1. Create a Firebase project and register Android package `com.bharathavedam.app`.
2. Add `google-services.json` to `app/`.
3. Enable Authentication, Firestore, Cloud Messaging, Analytics and Crashlytics as required.
4. Deploy Firestore rules/indexes and Cloud Functions.
5. Create an admin user and set the `admin=true` custom claim from a trusted server/admin script.
6. Connect the Android FirebaseBridge to callable functions for visitor/post-view writes.

## Admin Panel
`../admin/` contains a Firebase Web SDK based admin dashboard. Host it on Firebase Hosting or another HTTPS host. Replace the Web App Firebase configuration in `admin/app.js`, enable Email/Password Authentication, and grant the admin account the `admin=true` custom claim. The dashboard provides configuration, Today’s Thought, festival entry, report review, and analytics views. Notification sending is intentionally routed through the admin-only Cloud Function rather than exposing server credentials in the browser.
