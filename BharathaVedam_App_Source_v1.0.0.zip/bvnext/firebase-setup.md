# Firebase setup — Bharatha Vedam

This project is Firebase-ready but does **not** contain your private Firebase configuration.

## One-time account step
1. Create/open a Firebase project.
2. Add an Android app with package name `com.bharathavedam.app`.
3. Enable Google Analytics for Firebase.
4. Download `google-services.json` and place it in the `app/` folder.
5. Rebuild the app.

The project automatically applies the Google Services and Crashlytics Gradle plugins only when `app/google-services.json` exists.

## Services wired into the app
- Analytics: app opens, screen views, post views, push-token availability.
- Remote Config: feature/config values can be changed without an app update.
- Cloud Messaging: topic `bharatha_vedam_all` and a native notification receiver are wired.
- Crashlytics: error/crash bridge is wired; console-side activation is completed after Firebase setup.

## Recommended Remote Config keys
- `today_thought`
- `ads_enabled`
- `affiliate_enabled`
- `maintenance_mode`
- `panchang_endpoint`
- `minimum_supported_version`
- `festival_banner_enabled`

Do not put passwords, API secrets, private keys, or other confidential information in Remote Config.
