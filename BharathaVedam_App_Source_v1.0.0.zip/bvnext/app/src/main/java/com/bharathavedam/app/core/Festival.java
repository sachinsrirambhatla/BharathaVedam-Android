package com.bharathavedam.app.core;

public final class Festival {
    public final String name, date, tithi, pujaTime, significance, articleUrl;
    public Festival(String name, String date, String tithi, String pujaTime, String significance, String articleUrl) {
        this.name=name; this.date=date; this.tithi=tithi; this.pujaTime=pujaTime; this.significance=significance; this.articleUrl=articleUrl;
    }
}
