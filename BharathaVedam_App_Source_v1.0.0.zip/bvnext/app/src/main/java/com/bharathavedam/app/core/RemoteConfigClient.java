package com.bharathavedam.app.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Optional remote JSON configuration. Empty URL keeps the app fully offline. */
public final class RemoteConfigClient {
    public interface Callback { void onLoaded(JSONObject json); void onError(Exception e); }
    private final Context context;
    public RemoteConfigClient(Context context) { this.context = context.getApplicationContext(); }

    public void fetch(String endpoint, Callback callback) {
        if (endpoint == null || endpoint.trim().isEmpty()) return;
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(endpoint);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                if (conn.getResponseCode() / 100 != 2) throw new Exception("Remote config HTTP " + conn.getResponseCode());
                BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder b = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) b.append(line);
                JSONObject json = new JSONObject(b.toString());
                new Handler(Looper.getMainLooper()).post(() -> callback.onLoaded(json));
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onError(e));
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }
}
