package com.bharathavedam.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.*;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import java.io.File;
import java.io.FileOutputStream;
import com.bharathavedam.app.core.AppConfig;
import com.bharathavedam.app.core.AnalyticsTracker;
import com.bharathavedam.app.core.ErrorLogger;

public class MainActivity extends Activity {
    private AppConfig config;
    private AnalyticsTracker analytics;
    private ErrorLogger errorLogger;
    private com.bharathavedam.app.core.FirebaseBridge firebase;
    private static final String PREFS = "bharatha_vedam";
    private boolean dark = false;
    private LinearLayout root, content;
    private TextView toolbarTitle;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        dark = getSharedPreferences(PREFS, 0).getBoolean("dark", false);
        config = AppConfig.load(this);
        analytics = new AnalyticsTracker(this);
        errorLogger = new ErrorLogger(this);
        firebase = new com.bharathavedam.app.core.FirebaseBridge(this);
        firebase.fetchRemoteConfig();
        firebase.subscribeToTopic("bharatha_vedam_all");
        firebase.requestToken();
        analytics.appOpened();
        firebase.logScreen("home");
        showHome();
    }

    private int bg() { return dark ? Color.rgb(23,21,19) : Color.rgb(255,249,240); }
    private int card() { return dark ? Color.rgb(37,33,29) : Color.WHITE; }
    private int fg() { return dark ? Color.rgb(247,238,227) : Color.rgb(45,33,25); }
    private int saffron() { return Color.rgb(201,106,0); }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(fg());
        t.setPadding(0, 6, 0, 6);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(dark ? Color.WHITE : Color.rgb(80,45,20));
        return b;
    }

    private LinearLayout cardLayout() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(18, 16, 18, 16);
        c.setBackgroundResource(com.bharathavedam.app.R.drawable.bg_card);
        c.setBackgroundTintList(android.content.res.ColorStateList.valueOf(card()));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 10, 0, 10);
        c.setLayoutParams(lp);
        return c;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg());

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(12, 8, 8, 8);
        bar.setBackgroundColor(dark ? Color.rgb(55,40,25) : Color.rgb(247,228,199));

        Button menu = button("☰");
        menu.setOnClickListener(v -> showSettings());
        bar.addView(menu, new LinearLayout.LayoutParams(52, 56));

        toolbarTitle = text("🕉️  " + title, 20);
        toolbarTitle.setTypeface(null, Typeface.BOLD);
        bar.addView(toolbarTitle, new LinearLayout.LayoutParams(0, 56, 1));

        Button share = button("↗");
        share.setOnClickListener(v -> shareApp());
        bar.addView(share, new LinearLayout.LayoutParams(52, 56));

        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(16, 10, 16, 10);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(card());
        String[] labels = {"🏠 Home","🗓 Panchang","🪔 Festivals","🔍 Search","⚙ Settings"};
        View.OnClickListener[] clicks = {
            v -> showHome(), v -> showPanchang(), v -> showFestivals(), v -> showSearch(), v -> showSettings()
        };
        for (int i=0;i<labels.length;i++) {
            Button n = button(labels[i]);
            n.setTextSize(11);
            n.setOnClickListener(clicks[i]);
            nav.addView(n, new LinearLayout.LayoutParams(0, 58, 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    private void showHome() {
        base("భారత వేదం");

        LinearLayout hero = cardLayout();
        TextView h = text("🕉️ భారత వేదం", 27);
        h.setTextColor(saffron()); h.setTypeface(null, Typeface.BOLD);
        hero.addView(h);
        hero.addView(text("సనాతన ధర్మం • సంస్కృతి • ఆధ్యాత్మిక జ్ఞానం", 14));
        hero.addView(text("🕐 Live date & time • 🌙 తిథి • ⭐ నక్షత్రం", 15));
        content.addView(hero);

        LinearLayout thought = cardLayout();
        thought.addView(text("🕉️ Today’s Thought", 19));
        thought.addView(text("“" + config.todayThought + "”", 17));
        content.addView(thought);

        LinearLayout p = cardLayout();
        p.addView(text("🗓️ ఈరోజు పంచాంగం", 19));
        p.addView(text("తిథి • నక్షత్రం • వారము • సూర్యోదయం • సూర్యాస్తమయం", 15));
        Button full = button("పూర్తి పంచాంగం →");
        full.setOnClickListener(v -> showPanchang());
        p.addView(full);
        content.addView(p);

        LinearLayout f = cardLayout();
        f.addView(text("🪔 రాబోయే పండుగలు", 19));
        f.addView(text("పండుగ తేదీ, తిథి, పర్వదిన విశిష్టత మరియు సంబంధిత Bharatha Vedam కథనాలు.", 15));
        Button fb = button("పండుగలు చూడండి →");
        fb.setOnClickListener(v -> showFestivals());
        f.addView(fb);
        content.addView(f);

        LinearLayout mv = cardLayout();
        mv.addView(text("🔥 ఎక్కువగా చదివిన కథనాలు", 19));
        mv.addView(text("←  పండుగలు   •   ధర్మం   •   కథలు   •   క్షేత్రాలు   →", 15));
        Button post = button("“నారద దేవర్షి జయంతి” →");
        post.setOnClickListener(v -> openWeb("https://bharathavedam.blogspot.com/2026/05/blog-post.html"));
        mv.addView(post);
        content.addView(mv);

        LinearLayout social = cardLayout();
        social.addView(text("📲 భారత వేదాన్ని Follow చేయండి", 18));
        addSocialButtons(social);
        content.addView(social);
    }

    private void showPanchang() {
        if (firebase != null) firebase.logScreen("panchang");
        base("పంచాంగం");
        LinearLayout c = cardLayout();
        c.addView(text("📅 ఈరోజు పంచాంగం", 21));
        c.addView(text("స్థానం: Hyderabad, Telangana", 14));
        TextView live = text("Live Panchang data loading…", 16);
        c.addView(live);
        content.addView(c);
        fetchPanchang(live);
    }

    private void fetchPanchang(TextView target) {
        new Thread(() -> {
            try {
                java.text.SimpleDateFormat fmt =
                        new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
                String date = fmt.format(new java.util.Date());

                // Configurable provider endpoint. This demo uses VedicOrbit's documented
                // Telugu summary endpoint for Hyderabad. Production should use a licensed
                // commercial provider/API key where required.
                String endpoint = config.panchangEndpoint
                        + "?mode=summary"
                        + "&date=" + date
                        + "&lat=17.385"
                        + "&lon=78.4867"
                        + "&timezone=Asia/Kolkata"
                        + "&lang=te";

                HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) body.append(line);
                br.close();
                conn.disconnect();

                JSONObject json = new JSONObject(body.toString());
                JSONObject data = json.optJSONObject("data");
                StringBuilder display = new StringBuilder();

                if (data != null) {
                    appendIfPresent(display, "🌙 తిథి", data, "tithi");
                    appendIfPresent(display, "⭐ నక్షత్రం", data, "nakshatra");
                    appendIfPresent(display, "🪐 యోగం", data, "yoga");
                    appendIfPresent(display, "🔱 కరణం", data, "karana");
                    appendIfPresent(display, "🌅 సూర్యోదయం", data, "sunrise");
                    appendIfPresent(display, "🌇 సూర్యాస్తమయం", data, "sunset");
                    appendIfPresent(display, "📅 వారము", data, "weekday");
                }

                if (display.length() == 0) {
                    display.append("ఈరోజు పంచాంగ సమాచారం అందుబాటులో లేదు.");
                }

                runOnUiThread(() -> target.setText(display.toString()));
            } catch (Exception ex) {
                if (errorLogger != null) errorLogger.record("panchang", ex);
                runOnUiThread(() -> target.setText(
                        "పంచాంగ సమాచారం ప్రస్తుతం అందుబాటులో లేదు.\n"
                        + "దయచేసి కొద్దిసేపటి తర్వాత మళ్లీ ప్రయత్నించండి."));
            }
        }).start();
    }

    private void appendIfPresent(StringBuilder out, String label, JSONObject data, String key) {
        String value = data.optString(key, "");
        if (!value.isEmpty() && !"null".equalsIgnoreCase(value)) {
            out.append(label).append(": ").append(value).append("\n");
        }
    }

    private void showFestivals() {
        if (firebase != null) firebase.logScreen("festivals");
        base("పండుగలు");
        LinearLayout c = cardLayout();
        c.addView(text("🪔 Upcoming Festivals", 21));
        c.addView(text("ప్రతి పండుగకు తేదీ + పంచాంగ సమయం + విశిష్టత + సంబంధిత భారత వేదం కథనం.", 15));

        Button narada = button("🌼 నారద దేవర్షి జయంతి  • విశిష్టత చదవండి");
        narada.setOnClickListener(v -> { analytics.postViewed("https://bharathavedam.blogspot.com/2026/05/blog-post.html"); openWeb("https://bharathavedam.blogspot.com/2026/05/blog-post.html"); });
        c.addView(narada);

        Button shareCard = button("📤 Share Festival Card");
        shareCard.setOnClickListener(v -> shareFestivalCard("🪔 పర్వదిన శుభాకాంక్షలు", "ఈ పర్వదినం విశిష్టతను తెలుసుకోండి.", "భారత వేదం"));
        c.addView(shareCard);
        content.addView(c);
    }

    private void showSearch() {
        if (firebase != null) firebase.logScreen("search");
        base("శోధన");
        EditText e = new EditText(this);
        e.setHint("కథనాలు, పండుగలు, ధర్మం…");
        content.addView(e);
        Button b = button("🔍 Search Bharatha Vedam");
        b.setOnClickListener(v -> openWeb(config.siteUrl + "/search?q=" + Uri.encode(e.getText().toString())));
        content.addView(b);
    }

    private void showSettings() {
        if (firebase != null) firebase.logScreen("settings");
        base("సెట్టింగ్స్");
        LinearLayout theme = cardLayout();
        theme.addView(text("🎨 Theme", 20));
        Button toggle = button(dark ? "☀️ Light Mode" : "🌙 Dark Mode");
        toggle.setOnClickListener(v -> {
            dark = !dark;
            getSharedPreferences(PREFS,0).edit().putBoolean("dark",dark).apply();
            showSettings();
        });
        theme.addView(toggle);
        theme.addView(text("Saffron • Light • Dark • System theme architecture", 14));
        content.addView(theme);

        LinearLayout social = cardLayout();
        social.addView(text("📲 Social Channels", 20));
        addSocialButtons(social);
        content.addView(social);

        LinearLayout report = cardLayout();
        report.addView(text("🚩 Report / Recheck a Post", 20));
        report.addView(text("తప్పు సమాచారం, broken link లేదా ఇతర సమస్య ఉంటే report చేయండి.", 14));
        Button rb = button("Complaint / Report →");
        rb.setOnClickListener(v -> reportProblem());
        report.addView(rb);
        content.addView(report);

        LinearLayout about = cardLayout();
        about.addView(text("ℹ️ About", 20));
        about.addView(text("భారత వేదం • Version 1.0.0\nContact: " + REPORT, 14));
        about.addView(text("ఈరోజు local app opens: " + analytics.getTodayOpens(), 14));
        content.addView(about);
    }

    private void addSocialButtons(LinearLayout c) {
        Button w = button("🟢 WhatsApp  • Follow");
        w.setOnClickListener(v -> openWeb(config.whatsapp)); c.addView(w);
        Button t = button("🔵 Telegram  • Join");
        t.setOnClickListener(v -> openWeb(config.telegram)); c.addView(t);
        Button y = button("🔴 YouTube  • Subscribe");
        y.setOnClickListener(v -> openWeb(config.youtube)); c.addView(y);
    }

    private void openWeb(String url) {
        WebView w = new WebView(this);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient());
        w.loadUrl(url);
        setContentView(w);
    }

    private void shareApp() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, "భారత వేదం 🕉️\n" + config.siteUrl);
        startActivity(Intent.createChooser(i, "Share"));
    }

    private void reportProblem() {
        Intent i = new Intent(Intent.ACTION_SENDTO);
        i.setData(Uri.parse("mailto:" + config.reportEmail));
        i.putExtra(Intent.EXTRA_SUBJECT, "భారత వేదం App - Post Report");
        i.putExtra(Intent.EXTRA_TEXT, "Post title/link:\n\nProblem:\n\n");
        startActivity(i);
    }

    private void shareFestivalCard(String title, String body, String footer) {
        Bitmap bmp = Bitmap.createBitmap(1080, 1350, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(Color.rgb(255, 247, 235));

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.rgb(201,106,0)); p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(76);
        c.drawText("🪔", 540, 180, p);
        p.setTextSize(52); c.drawText(title, 540, 300, p);
        p.setColor(Color.rgb(74,42,22)); p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(38); c.drawText(body, 540, 500, p);
        p.setColor(Color.rgb(201,106,0)); p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(46); c.drawText(footer, 540, 1120, p);
        p.setColor(Color.rgb(125,107,90)); p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(28); c.drawText("bharathavedam.blogspot.com", 540, 1180, p);

        try {
            File dir = new File(getCacheDir(), "shared");
            dir.mkdirs();
            File file = new File(dir, "bharatha_vedam_festival.png");
            FileOutputStream out = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();

            Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/png");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TEXT, "🪔 పర్వదిన శుభాకాంక్షలు — భారత వేదం");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "Share Festival Card"));
        } catch (Exception e) {
            shareApp();
        }
    }
}
