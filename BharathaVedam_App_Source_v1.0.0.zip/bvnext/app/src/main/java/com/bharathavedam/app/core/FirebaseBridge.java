package com.bharathavedam.app.core;

import android.content.Context;
import android.os.Bundle;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.messaging.FirebaseMessaging;

/** Optional Firebase integration. It stays dormant until google-services.json is added. */
public final class FirebaseBridge {
    private final Context context;
    private FirebaseAnalytics analytics;
    private FirebaseRemoteConfig remoteConfig;
    private FirebaseCrashlytics crashlytics;

    public FirebaseBridge(Context context) {
        this.context = context.getApplicationContext();
        if (!isConfigured()) return;
        try {
            analytics = FirebaseAnalytics.getInstance(this.context);
            remoteConfig = FirebaseRemoteConfig.getInstance();
            crashlytics = FirebaseCrashlytics.getInstance();
        } catch (Exception ignored) { }
    }

    public boolean isConfigured() {
        try { return !FirebaseApp.getApps(context).isEmpty(); }
        catch (Exception e) { return false; }
    }

    public void logScreen(String screen) {
        if (analytics == null) return;
        Bundle b = new Bundle();
        b.putString(FirebaseAnalytics.Param.SCREEN_NAME, screen);
        analytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, b);
    }

    public void logPostView(String title, String url) {
        if (analytics == null) return;
        Bundle b = new Bundle();
        b.putString("post_title", title);
        b.putString("post_url", url);
        analytics.logEvent("post_view", b);
    }

    public void logError(String message) {
        if (crashlytics == null) return;
        crashlytics.log(message == null ? "unknown_error" : message);
    }

    public void recordException(Exception e) {
        if (crashlytics != null && e != null) crashlytics.recordException(e);
    }

    public void fetchRemoteConfig() {
        if (remoteConfig == null) return;
        remoteConfig.fetchAndActivate().addOnCompleteListener(task -> { });
    }

    public String getRemoteString(String key, String fallback) {
        if (remoteConfig == null) return fallback;
        String value = remoteConfig.getString(key);
        return value == null || value.isEmpty() ? fallback : value;
    }

    public boolean getRemoteBoolean(String key, boolean fallback) {
        return remoteConfig == null ? fallback : remoteConfig.getBoolean(key);
    }

    public void requestToken() {
        if (!isConfigured()) return;
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            if (analytics != null) {
                Bundle b = new Bundle();
                b.putString("token_available", "true");
                analytics.logEvent("push_token_ready", b);
            }
        });
    }

    public void subscribeToTopic(String topic) {
        if (topic == null || topic.trim().isEmpty() || !isConfigured()) return;
        FirebaseMessaging.getInstance().subscribeToTopic(topic.trim());
    }
}
