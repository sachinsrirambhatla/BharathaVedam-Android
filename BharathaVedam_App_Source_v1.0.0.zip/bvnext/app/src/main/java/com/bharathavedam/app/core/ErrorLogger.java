package com.bharathavedam.app.core;

import android.content.Context;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Crash/API error hook. Stores a small local diagnostic record for future remote monitoring. */
public final class ErrorLogger {
    private static final String TAG = "BharathaVedam";
    private final android.content.SharedPreferences prefs;
    public ErrorLogger(Context c) { prefs = c.getSharedPreferences("bv_errors", Context.MODE_PRIVATE); }
    public void record(String source, Throwable error) {
        String msg = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())
                + " | " + source + " | " + (error == null ? "unknown" : error.toString());
        prefs.edit().putString("last_error", msg).apply();
        Log.e(TAG, msg, error);
    }
    public String lastError() { return prefs.getString("last_error", "No errors recorded."); }
}
