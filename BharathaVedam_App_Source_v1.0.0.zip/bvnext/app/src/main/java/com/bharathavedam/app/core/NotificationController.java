package com.bharathavedam.app.core;

import android.content.Context;
import android.content.SharedPreferences;

/** Notification preference abstraction. Connect to FCM/another push service in production. */
public final class NotificationController {
    private final SharedPreferences prefs;
    public NotificationController(Context c) { prefs = c.getSharedPreferences("bv_notifications", Context.MODE_PRIVATE); }
    public boolean isEnabled(String category) { return prefs.getBoolean(category, true); }
    public void setEnabled(String category, boolean enabled) { prefs.edit().putBoolean(category, enabled).apply(); }
}
