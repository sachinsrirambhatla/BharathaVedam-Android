package com.bharathavedam.app.core;

import android.content.Context;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Backend-ready remote configuration model. Defaults keep the app functional offline. */
public final class AppConfig {
    public String siteUrl = "https://bharathavedam.blogspot.com";
    public String reportEmail = "sachin.srirambhatla@gmail.com";
    public String whatsapp = "https://whatsapp.com/channel/0029Va5maOo2975L9DOY3u3t";
    public String telegram = "https://t.me/Bharathavedam1";
    public String youtube = "https://youtube.com/@bharathavedham";
    public String panchangEndpoint = "https://vedicorbit-website.vercel.app/api/panchangam";
    public boolean adsEnabled = false;
    public boolean affiliateEnabled = false;
    public boolean notificationsEnabled = true;
    public String todayThought = "ధర్మాన్ని ఆచరించడం మన జీవితానికి దిశను ఇస్తుంది.";

    public static AppConfig load(Context context) {
        AppConfig c = new AppConfig();
        try (InputStream in = context.getAssets().open("app_config.json")) {
            byte[] bytes = new byte[in.available()];
            in.read(bytes);
            JSONObject j = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            c.siteUrl = j.optString("siteUrl", c.siteUrl);
            c.reportEmail = j.optString("reportEmail", c.reportEmail);
            c.whatsapp = j.optString("whatsapp", c.whatsapp);
            c.telegram = j.optString("telegram", c.telegram);
            c.youtube = j.optString("youtube", c.youtube);
            c.panchangEndpoint = j.optString("panchangEndpoint", c.panchangEndpoint);
            c.adsEnabled = j.optBoolean("adsEnabled", c.adsEnabled);
            c.affiliateEnabled = j.optBoolean("affiliateEnabled", c.affiliateEnabled);
            c.notificationsEnabled = j.optBoolean("notificationsEnabled", c.notificationsEnabled);
            c.todayThought = j.optString("todayThought", c.todayThought);
        } catch (Exception ignored) { }
        return c;
    }
}
