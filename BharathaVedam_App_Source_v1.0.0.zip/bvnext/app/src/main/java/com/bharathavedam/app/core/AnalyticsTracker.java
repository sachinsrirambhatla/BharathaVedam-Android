package com.bharathavedam.app.core;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Local analytics abstraction. Replace/bridge with Firebase or another provider later. */
public final class AnalyticsTracker {
    private final SharedPreferences prefs;
    public AnalyticsTracker(Context c) { prefs = c.getSharedPreferences("bv_analytics", Context.MODE_PRIVATE); }

    public void appOpened() {
        increment("app_open");
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        prefs.edit().putInt("opens:" + day, prefs.getInt("opens:" + day, 0) + 1).apply();
    }
    public void postViewed(String postUrl) { increment("post_view"); increment("post:" + safe(postUrl)); }
    public int getTodayOpens() {
        String key = "opens:" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        return prefs.getInt(key, 0);
    }
    private void increment(String key) { prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply(); }
    private String safe(String s) { return Integer.toHexString(s == null ? 0 : s.hashCode()); }
}
